/* I pledge my honor that I have abided by the Stevens Honor System
 * Brandon Patton
 * cs392_echoserver.c
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cs392_log.h"

#define BUFFSIZE 1024
#define MAXPENDING 5


int read_from_client(int filedes){
	char buffer[BUFFSIZE];
	int nbytes;
	nbytes = read(filedes, buffer, BUFFSIZE);
	if(nbytes < 0){
		perror("read");
	 	exit(EXIT_FAILURE);
	} else if (nbytes == 0) {
		return -1;
	} else {
		cs392_socket_log("Host: %s, Port: %hd\n");	
		return 0;
	}
}


int main(int argc, char *argv[]){
	
	int echo_socket;
	fd_set active_fd_set, read_fd_set;
	int i;
	char buffer[BUFFSIZE];
	struct sockaddr_in echoserver, echoclient;
	unsigned int size; 
	size = (sizeof(echoclient));
	echo_socket = socket(AF_INET, SOCK_STREAM, 0); 
	memset(&echoserver, 0, sizeof(echoserver));
	echoserver.sin_family = AF_INET;
	echoserver.sin_addr.s_addr = htonl(INADDR_ANY);
	echoserver.sin_port = htons(atoi(argv[1]));
	bind(echo_socket, (struct sockaddr *) &echoserver, sizeof(echoserver));
	listen(echo_socket, MAXPENDING);
	FD_ZERO(&active_fd_set);
	FD_SET(echo_socket, &active_fd_set);
	while(1){
		read_fd_set = active_fd_set;
		if(select(FD_SETSIZE, &read_fd_set, NULL, NULL, NULL) < 0){
			perror("select");
			exit(EXIT_FAILURE);
		}
		for(i = 0; i < FD_SETSIZE; ++i){
			if(FD_ISSET (i, &read_fd_set)){
				if(i == echo_socket){
					int c_socket;
					c_socket = accept(echo_socket, (struct sockaddr *) &echoclient, &size);
					if (c_socket < 0){
						perror("accept");
						exit(EXIT_FAILURE);
					}	
					FD_SET (c_socket, &active_fd_set);
					//log using %s and %hd.\n from fprintf line
					//use char *log to put ip address and port into to log
					cs392_socket_log("Host: %s, Port: %hd\n");
					recv(c_socket, buffer, BUFFSIZE, 0);
					send(c_socket, buffer, BUFFSIZE, 0);
					close(c_socket);
				} else {
					if(read_from_client(i) < 0){
						close(i);
						FD_CLR (i, &active_fd_set);
						
					}
				}
			}
		}
	}
	free(buffer);
}
