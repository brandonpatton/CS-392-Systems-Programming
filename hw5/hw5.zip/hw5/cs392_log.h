/* I pledge my honor that I have abided by the Stevens Honor System
 * Brandon Patton
 * cs392_log.h
 */
#ifndef CS392_LOG_H
#define CS392_LOG_H
#include <stdio.h>

void cs392_socket_log(char *);

#endif


