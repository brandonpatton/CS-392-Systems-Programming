/* I pledge my honor that I have abided by the Stevens Honor System
 * Brandon Patton
 * cs392_echoclient.c
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#define BUFFSIZE 1024

int main(int argc, char *argv[]){
	while (1){
		int c_socket;
		struct sockaddr_in echoserver;
		char buffer[BUFFSIZE];
		unsigned int echolen;
		int received = 0;
		c_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		memset(&echoserver, 0, sizeof(echoserver));
		echoserver.sin_family = AF_INET;
		echoserver.sin_addr.s_addr = inet_addr(argv[1]); //ip address
		echoserver.sin_port = htons(atoi(argv[3])); //port
		connect(c_socket, (struct sockaddr *) &echoserver, sizeof(echoserver));
		echolen = strlen(argv[2]);
		send(c_socket, argv[2], echolen, 0);
		recv(c_socket, buffer, BUFFSIZE-1, 0);
		printf("%s", buffer);
		close(c_socket);
		exit(0);
	}
}
