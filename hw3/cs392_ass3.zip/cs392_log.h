/* I pledge my honor that I have abided by the Stevens Honor System
 * Brandon Patton
 * Assignment 3
 */
#ifndef CS392_LOG_H
#define CS392_LOG_H
#include <stdio.h>

void logH(char*);

#endif


