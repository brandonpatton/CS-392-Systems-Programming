/* I pledge my honor that I have abided by the Stevens Honor System.
 * Brandon Patton
 * CS392 Assignment 2
 * string.h
 */

#ifndef STRING_H
#define STRING_H
typedef unsigned int uint;
void *cs392_memcpy(void *dst, void *src, unsigned num);
unsigned cs392_strlen(char *str);

#endif
