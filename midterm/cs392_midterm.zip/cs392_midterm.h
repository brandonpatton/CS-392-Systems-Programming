/* I pledge my honor that I have abided by the Stevens Honor System.
 * Brandon Patton
 * CS392 Midterm
 */
	
#ifndef MIDTERM_H
#define MIDTERM_H
char *cs392_strcpy(char *dest, char *src);
int cs392_strcmp(char *s1, char *s2);
char *cs392_strncat(char *dest, char *src, unsigned n);
#endif
